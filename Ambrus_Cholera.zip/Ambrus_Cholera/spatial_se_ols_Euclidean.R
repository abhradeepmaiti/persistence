Spatial_HAC_Euclidean=function(equation,
                     study_file,
                     range_search,
                     Smoothness=0.5,
                     residual_upper=1000,residual_lower= -1000,
                     opt_method="GCV"){
  

#This is a simple wrapper function to let you compute Matern SEs with a minimal knowledge of R.
#All it does, in effect, is to compute the range and spatial structure of the OLS residuals using the fields
#package.
#This is for case where distances are Euclidean not geodesic

fm_ols=as.formula(equation)   

ols=lm(fm_ols,data=study_file)
Coords=cbind(study_file$X,study_file$Y)
Residuals=ols$residuals

##Truncate high values which will mess up spatial parameter ests
Residuals=ifelse(Residuals>residual_upper,residual_upper,Residuals)
Residuals=ifelse(Residuals<residual_lower,residual_lower,Residuals)

###########compute moran stat for spatial autocorrelation
study_spatial=SpatialPoints(coords=Coords)

nearest=knn2nb(knearneigh(study_spatial,k=5,longlat = F))   #k nearest neighbours
nearest=nb2listw(nearest,style="W")
Moran_z=as.vector(lm.morantest(ols,listw=nearest)$statistic)

###scale residuals to mean=0 and sd=1 to get correlation matrix
kappa=Smoothness
hold_search=data.frame(range_search,lambda=NA,loglik=NA)
for (j in 1:length(range_search)){
  fit_search = Krig(  x = Coords,
                      Y = scale(Residuals),
                      Distance = "rdist",
                      Covariance = "Matern", 
                      smoothness = kappa,
                      theta = range_search[j],
                      give.warnings = FALSE,
                      method=opt_method
  )
  
  hold_search[j,2:3]=fit_search$lambda.est[6,c(1,5)]
}

cov_par=hold_search %>% arrange(loglik) %>% slice(1) %>% as.numeric()

if(cov_par[1]==max(range_search)) warning("Your range search values are too low: try higher ones.")
if(cov_par[1]==min(range_search)) warning("Your range search values are too high: try lower ones.")

Effective_Range_km=sqrt(8*kappa)*cov_par[1]  #in whatever units you are using
Range=as.numeric(cov_par[1])
Structure=as.numeric(1/(1+cov_par[2]))  #this is weight rho between systematic correlation and spatial noise
loglik=-as.numeric(cov_par[3])

spatial_parameters=data.frame(Range,Effective_Range_km,Structure,Moran_z,Smoothness=kappa,
                              loglik)
#######weighting kernel is here
KL=Structure*fields::Matern(rdist(x1=Coords),
                                  range=Range,smoothness=kappa)+
  diag(nrow(Coords))*(1-Structure)

##Calculate HAC standard errors
  X=qr.X(ols$qr)
  N=nrow(X)
  k=ncol(X)
  U=ols$res         
  V=t(X)%*%(U*KL*U)%*%X/N
  sv_X=svd(X)   #invert X'X using SVD
  v=sv_X$v
  d_2=diag(sv_X$d^(-2))
  xx.inv = N *(v %*% d_2 %*% t(v))
  Cov=xx.inv%*%V%*%xx.inv/N
  hac.se=sqrt(diag(Cov))
  hac.t=summary(ols)$coef[,1]/hac.se
  hac.p=2*(1-pnorm(abs(hac.t)))
  hac=cbind.data.frame(coef=ols$coef,hac.se,hac.t,hac.p)

###############spatial kriging
fit=Krig(  x = Coords,
           Y = scale(Residuals),
           Distance = "rdist",
           Covariance = "Matern", 
           smoothness = 0.5,
           theta = Range,
           give.warnings = FALSE)

output=list(HAC=hac,Spatial_Parameters=spatial_parameters,fit=fit,OLS=ols,Residuals=Residuals)
return(output)
}

