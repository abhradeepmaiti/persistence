Spatial_HAC_NLS=function(nls_output,
                     study_file,
                     range_search,
                     Smoothness=0.5,
                     residual_upper=1000,
                     residual_lower= -1000,
                     subset_obs=1:nrow(study_file),
                     spatial_fit=F,
                     opt_method="REML"){
  
###In this case nls is output of any nonlinear regression that supports sandwich covariance

  # This is a simple function to calculate HAC standard errors using a Matern kernel as outlined in
  # Understanding Persistence. It is basically a wrapper around the Krig command in fields library.
  #
  # range_search is a sequence of values where the MLE of structure is calculated: the function chooses
  # the maximum likelihood values.
  #
  # Smoothness gives the smoothness of the Matern function, set to exponential (0.5) by default.
  #
  # residual_lower and upper allow you to set values at which to truncate outlying residuals that
  # can interfere with calculating spatial parameters.
  #
  # subset_obs allows you to choose a subset of residuals for calculating spatial params.
  #
  # spatial_fit tells whether the MLE values from Krig should be returned: useful for diagnostic plots but can be v large.
  #
  # opt_method sets the optimization method to be used by Krig function.
  
Coords=study_file %>% select(X,Y) %>% as.matrix() 

Residuals=nls_output$residuals

Residuals[-subset_obs]=NA

##Truncate high values which will mess up spatial parameter ests
Residuals=ifelse(Residuals>residual_upper,residual_upper,Residuals)
Residuals=ifelse(Residuals<residual_lower,residual_lower,Residuals)

###########compute moran stat for spatial autocorrelation
study_spatial=SpatialPoints(coords=Coords)

nearest=knn2nb(knearneigh(study_spatial,k=5,longlat = T))   #k nearest neighbours
nearest=nb2listw(nearest,style="W")
Moran_z=as.vector(moran.test(Residuals,listw=nearest)$statistic)

###scale residuals to mean=0 and sd=1 to get correlation matrix
kappa=Smoothness
#Coords_sample=Coords[subset_obs,]   #study_file %>% select(X,Y) %>% slice(subset_obs)%>% as.matrix() 

hold_search=data.frame(range_search,lambda=NA,loglik=NA)
for (j in 1:length(range_search)){
  fit_search = Krig(  x = Coords,
                      Y = scale(Residuals),
                      Distance = "rdist.earth",
                      Covariance = "Matern", 
                      smoothness = kappa,
                      theta = range_search[j],
                      give.warnings = FALSE,
                      method=opt_method
  )
  
  hold_search[j,2:3]=fit_search$lambda.est[6,c(1,5)]
}

cov_par=hold_search %>% arrange(loglik) %>% slice(1) %>% as.numeric()

if(cov_par[1]==max(range_search)) warning("Your range search values are too low: try higher ones.")
if(cov_par[1]==min(range_search)) warning("Your range search values are too high: try lower ones.")

Effective_Range_km=1.6*sqrt(8*kappa)*cov_par[1]  #in kilometres
Range=as.numeric(cov_par[1])
Structure=as.numeric(1/(1+cov_par[2]))  #this is weight rho between systematic correlation and spatial noise
loglik=-as.numeric(cov_par[3])

spatial_parameters=data.frame(Range,Effective_Range_km,Structure,Moran_z,Smoothness=kappa,
                              loglik)
#######weighting kernel is here
KL=Structure*fields::Matern(rdist.earth(x1=Coords),
                                  range=Range,smoothness=kappa)+
  diag(nrow(Coords))*(1-Structure)

##Calculate HAC standard errors
brd=bread(nls_output)
psi=estfun(nls_output)
N=nrow(psi)
r=matrix(0,ncol(psi),ncol(psi))
for (i in 1:N){
  for(j in 1:N ){
    r=r+KL[i,j]*tcrossprod(psi[i,],psi[j,])
  }
}
mt=r/N
se=sqrt(diag(brd%*%mt%*%brd/N))
z.stat=summary(nls_output)$coef[,1]/se
p.value=2*(1-pnorm(abs(z.stat)))
hac=data.frame(Estimate=summary(nls_output)$coef[,1],'Std. Error'=se,'z stat'=z.stat,'Pr.z'=p.value)
  

###############spatial kriging
fit= ifelse(spatial_fit,
            Krig(
              x = Coords,
              Y = scale(Residuals),
              Distance = "rdist.earth",
              Covariance = "Matern",
              smoothness = 0.5,
              theta = Range,
              give.warnings = FALSE
            ),
            "Krig output not returned"
)

output=list(HAC=hac,Spatial_Parameters=spatial_parameters,fit=fit,NLS=nls_output,Residuals=Residuals)
return(output)
}

