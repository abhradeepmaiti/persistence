Spatial_HAC = function(equation,
                       study_file,
                       range_search,
                       Smoothness = 0.5,
                       residual_upper = 1000,
                       residual_lower = -1000,
                       subset_obs = 1:nrow(study_file),
                       spatial_fit=F,
                       opt_method = "REML") {
  #
  # This is a simple function to calculate HAC standard errors using a Matern kernel as outlined in
  # Understanding Persistence. It is basically a wrapper around the Krig command in fields library.
  #
  # range_search is a sequence of values where the MLE of structure is calculated: the function chooses
  # the maximum likelihood values.
  #
  # Smoothness gives the smoothness of the Matern function, set to exponential (0.5) by default.
  #
  # residual_lower and upper allow you to set values at which to truncate outlying residuals that
  # can interfere with calculating spatial parameters.
  #
  # subset_obs allows you to choose a subset of residuals for calculating spatial params.
  #
  # spatial_fit tells whether the MLE values from Krig should be returned: useful for diagnostic plots but can be v large.
  #
  # opt_method sets the optimization method to be used by Krig function.
  
  
  fm_ols = as.formula(equation)
  
  ols = lm(fm_ols, data = study_file)
  
  Coords = study_file %>% select(X, Y) %>% as.matrix()
  if (anyDuplicated(Coords)>0) stop("Duplicated coordinates: you should omit duplicates or jitter locations.")
  
  Residuals = ols$residuals
  Residuals[-subset_obs] = NA
  
  ##Truncate high values which can mess up spatial parameter ests
  Residuals = ifelse(Residuals > residual_upper, residual_upper, Residuals)
  Residuals = ifelse(Residuals < residual_lower, residual_lower, Residuals)
  
  ###########compute moran stat for spatial autocorrelation
  study_spatial = SpatialPoints(coords = Coords)
  proj4string(study_spatial) = CRS("+proj=longlat +datum=WGS84")
  
  nearest = knn2nb(knearneigh(study_spatial, k = 5, longlat = T))   #k nearest neighbours
  nearest = nb2listw(nearest, style = "W")
  Moran_z = as.vector(lm.morantest(ols, listw = nearest)$statistic)
  
  ###scale residuals to mean=0 and sd=1 to get correlation matrix
  kappa = Smoothness
  hold_search = data.frame(range_search, lambda = NA, loglik = NA)
  
  for (j in 1:length(range_search)) {
    fit_search = Krig(
      x = Coords,
      Y = scale(Residuals),
      Distance = "rdist.earth",
      Covariance = "Matern",
      smoothness = kappa,
      theta = range_search[j],
      give.warnings = FALSE,
      method = opt_method
    )
    # print(j)
    hold_search[j, 2:3] = fit_search$lambda.est[6, c(1, 5)]
  }
  
  cov_par = hold_search %>% arrange(loglik) %>% slice(1) %>% as.numeric()
  
  #If MLE range is at end of search range print warning
  
  if (cov_par[1] == max(range_search))
    warning("Your range search values are too low: try higher ones.")
  if (cov_par[1] == min(range_search))
    warning("Your range search values are too high: try lower ones.")
  
  
  ############MLE estimates of spatial parameters
  Range = as.numeric(cov_par[1])
  Effective_Range_km = 1.6 * sqrt(8 * kappa) * Range  #in kilometres: fields uses miles
  Structure = as.numeric(1 / (1 + cov_par[2]))  #this is weight rho between systematic correlation and spatial noise
  loglik = -as.numeric(cov_par[3])
  
  spatial_parameters = data.frame(Range,
                                  Effective_Range_km,
                                  Structure,
                                  Moran_z,
                                  Smoothness = kappa,
                                  loglik)
  
  #######weighting kernel is here
  KL = Structure * fields::Matern(rdist.earth(x1 = Coords),
                                  range = Range,
                                  smoothness = kappa) +
    diag(nrow(Coords)) * (1 - Structure)
  
  ##Calculate HAC standard errors
  X = qr.X(ols$qr)
  N = nrow(X)
  k = ncol(X)
  U = ols$res
  V = t(X) %*% (U * KL * U) %*% X / N
  sv_X=svd(X)   #invert X'X using SVD
  v=sv_X$v
  d_2=diag(sv_X$d^(-2))
  xx.inv = N *(v %*% d_2 %*% t(v))
  Cov = xx.inv %*% V %*% xx.inv / N
  hac.se = sqrt(diag(Cov))
  hac.t = summary(ols)$coef[, 1] / hac.se
  hac.p = 2 * (1 - pnorm(abs(hac.t)))
  hac = cbind.data.frame(coef = ols$coef, hac.se, hac.t, hac.p)
  
  ###############spatial kriging fit at MLE parameters
 fit= ifelse(spatial_fit,
  Krig(
    x = Coords,
    Y = scale(Residuals),
    Distance = "rdist.earth",
    Covariance = "Matern",
    smoothness = 0.5,
    theta = Range,
    give.warnings = FALSE
    ),
    "Krig output not returned"
  )
  
  output = list(
    HAC = hac,
    Spatial_Parameters = spatial_parameters,
    fit = fit,
    OLS = ols,
    Residuals = Residuals
  )
  return(output)
}
